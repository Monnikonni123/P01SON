This "virus" is made by Monni. DO NOT USE THIS VIRUS INCORRECTLY.
These are the steps of using it safely.
1. Open the .bat file named P01S0N.
2. When you want to stop this "virus" from looping Command Prompt, you simply press CTRL + ALT + DELETE.
If CTRL + ALT + DELETE Didn't work, you should try to hold down your PC's power button for 10 seconds.
If that didn't work, you're f****d